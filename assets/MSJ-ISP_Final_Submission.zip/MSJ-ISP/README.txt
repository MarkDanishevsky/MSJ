To start playing the game, compile the Main.java file, and run it from that directory (\MSJ-ISP).
If an error occurs, the most likely cause is that not all the files are compiled.

We hope you enjoy our game!