Monday June 9th, 2025

To start playing the game, run the Main.java file.